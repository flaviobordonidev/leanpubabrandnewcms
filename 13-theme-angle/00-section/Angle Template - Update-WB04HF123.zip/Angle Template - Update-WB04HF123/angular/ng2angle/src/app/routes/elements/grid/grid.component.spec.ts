/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { GridComponent } from './grid.component';

describe('Component: Grid', () => {
  it('should create an instance', () => {
    let component = new GridComponent();
    expect(component).toBeTruthy();
  });
});
