/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ColorsComponent } from './colors.component';

describe('Component: Colors', () => {
  it('should create an instance', () => {
    let component = new ColorsComponent();
    expect(component).toBeTruthy();
  });
});
