/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TypographyComponent } from './typography.component';

describe('Component: Typography', () => {
  it('should create an instance', () => {
    let component = new TypographyComponent();
    expect(component).toBeTruthy();
  });
});
