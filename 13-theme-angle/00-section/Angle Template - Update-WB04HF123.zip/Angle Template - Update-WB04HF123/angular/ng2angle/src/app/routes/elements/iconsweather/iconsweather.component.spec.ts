/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { IconsweatherComponent } from './iconsweather.component';

describe('Component: Iconsweather', () => {
  it('should create an instance', () => {
    let component = new IconsweatherComponent();
    expect(component).toBeTruthy();
  });
});
