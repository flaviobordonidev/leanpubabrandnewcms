// /* tslint:disable:no-unused-variable */

// import { TestBed, async, inject } from '@angular/core/testing';
// import { NavsearchComponent } from './navsearch.component';

// import { ElementRef } from '@angular/core';

// describe('Component: Navsearch', () => {

//     beforeEach(() => {
//         TestBed.configureTestingModule({
//             providers: [ElementRef]
//         }).compileComponents();
//     });

//     it('should create an instance', () => {
//         let component = new NavsearchComponent(new ElementRef({}));
//         expect(component).toBeTruthy();
//     });
// });
